/*
 * Angular
 */
import {Component} from '@angular/core';

@Component({
  selector: 'contact',
  template: `<h1>Contact Us</h1>`
})
export class ContactComponent {
}
