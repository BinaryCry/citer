# TODO

- "More tasks executed then were scheduled" exception thrown - see: https://github.com/angular/zone.js/issues/287 -nm 2016-04-28
