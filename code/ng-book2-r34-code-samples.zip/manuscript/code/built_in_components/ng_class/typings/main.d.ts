/// <reference path="main/ambient/es6-shim/index.d.ts" />
